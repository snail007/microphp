<?php
class User extends WoniuModel{
   public function getNameById($id){
       return $id.':Jhon';
   }
}
