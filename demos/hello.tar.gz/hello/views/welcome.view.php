My name is:<?php echo $name;?> 
