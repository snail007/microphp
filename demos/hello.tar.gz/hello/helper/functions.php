<?php
$app_name='MicroPHP';
$config['ver']='1.0';
function woniu(){
    echo 'Hello,MicroPHP!';
} 
