<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
    </head>
    <body>
        <h3>通过自定义父类控制器达到定制$this->message()默认视图功能</h3>
        <?php
        echo $msg;
        ?>
    </body>
</html>
