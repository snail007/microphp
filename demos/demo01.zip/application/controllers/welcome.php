<?php

/**
 * Description of index
 *
 * @author Administrator
 */
class Welcome extends FrontController {

    public function doIndex() {
        $this->message('Hello World!');
    }

}
