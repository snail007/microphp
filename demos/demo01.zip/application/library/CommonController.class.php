<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of TestLibrary
 *
 * @author Administrator
 */
class CommonController extends WoniuController {

    public function message($msg, $url = null, $time = 3) {
        $view = 'message';
        parent::message($msg, $view, $url, $time);
    }

}
