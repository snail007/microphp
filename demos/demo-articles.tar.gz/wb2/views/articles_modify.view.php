<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <style type="text/css">
            body{font-size:15px;padding:30px;}
            fieldset{width:820px;margin:0 auto;}
            fieldset div{margin-top:5px;}
            .hr1{border-bottom:2px solid #0066FF;margin:0;padding:0;}
            table{
                border-collapse:collapse;
            }
            td{padding:5px;}
            input[type=button],input[type=submit]{
                cursor:pointer;
                padding:2px 5px;
            }
            input[type=text]{
                padding:5px;
                border:#21cad0 solid thin;
            }
        </style>
        <link rel="stylesheet" type="text/css" href="<?php  echo $this->res_folder ;?>/js/ea/edit_area.css"/>
        <link rel="stylesheet" type="text/css" href="<?php  echo $this->res_folder ;?>/js/kd/plugins/code/prettify.css" />
        <link rel="stylesheet" type="text/css" href="<?php  echo $this->res_folder ;?>/ui/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="<?php  echo $this->res_folder ;?>/ui/css/bootstrap-theme.min.css" />
        <script src="<?php  echo $this->res_folder ;?>/js/ea/edit_area_full.js"></script>
        <script src="<?php  echo $this->res_folder ;?>/ui/jquery.js"></script>
        <script src="<?php  echo $this->res_folder ;?>/js/kd/kindeditor-min.js"></script>
        <script src="<?php  echo $this->res_folder ;?>/js/jq/form.js"></script>
        <script src="<?php  echo $this->res_folder ;?>/js/jq/ajaxqueue.js"></script> 
        <script src="<?php  echo $this->res_folder ;?>/js/kd/plugins/code/prettify.js"></script>
        <script src="<?php  echo $this->res_folder ;?>/ui/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="<?php  echo $this->res_folder ;?>/ui/style.css" />
        <script src="<?php  echo $this->res_folder ;?>/ui/style.js"></script>
        <?php  enableSelectDefault();?>
        <script>
            var found = false;
            var _editor = [];
            var actionName = '<?php  echo $this->controller_path ;?>';
            KindEditor.ready(function(K) {
                $('textarea.textareahtml').each(function() {
                    var id = $(this).attr('id');
                    _editor.push(
                            K.create('#' + id, {//指定textarea
                                uploadJson: '?' + actionName + '.uploadJson',
                                fileManagerJson: '?' + actionName + '.fileManagerJson',
                                cssPath: '<?php  echo $this->res_folder ;?>/js/kd/plugins/code/prettify.css',
                                emoticonsPath: '<?php  echo $this->res_folder ;?>/image/emoticons/images/',
                                allowFileManager: true
                            })
                            );
                });
                prettyPrint();//执行代码高亮
            });
            $(function() {
                $('textarea.code').each(function() {
                    var id = $(this).attr('id');
                    if (!id) {
                        id = 'code_' + String.valueOf(Math.random()).substr(2);
                        $(this).attr('id', id);
                    }
                    var type = $(this).attr('default-code-type') || 'html';
                    editAreaLoader.init({
                        id: id	// id of the textarea to transform	
                        , start_highlight: true
                        , allow_toggle: false
                        , word_wrap: true
                        , language: "zh"
                        , syntax: type
                        , toolbar: "word_wrap,search, |, undo, redo, |, syntax_selection, |, change_smooth_selection, reset_highlight, |, help"
                        , syntax_selection_allow: "html,js,css,php"
                        , show_line_colors: true
                    });
                });
                $('#cform').submit(function() {
                    $('textarea.textareahtml').each(function(i) {
                        try {
                            $(this).val(_editor[i].html());
                        } catch (e) {
                        }
                    });
                    $('textarea.code').each(function() {
                        try {
                            $(this).val(editAreaLoader.getValue($(this).attr('id')));
                        }
                        catch (e) {
                        }
                    });
                    $(this).ajaxSubmit({
                        dataType: 'json'
                        , success: function(data, status_t, xhr) {
                            if (typeof data == 'object' && data.tip) {

                                showInfoWindow(data.tip);
                            }
                        }
                        , error: function(xhr) {
                            showInfoWindow('通信出错,代码[' + xhr.status + ']');
                        }
                        , beforeSubmit: function() {
                            if (found) {
                                showInfoWindow('正在处理...');
                            }
                        }
                    });
                    return false;
                });
                $('#cboxSaveRomote').click(function() {
                    // alert();return;
                    if (this.checked) {
                        for (i = 0; i < _editor.length; i++) {
                            saveRomoteImgs(_editor[i], '?' + actionName + '.saveRemoteImage');
                        }
                    }
                });
            });
            //###########自动保存相关函数#######################
            function saveRomoteImgs(KE, scriptUrl) {
                var CheckboxId = "cboxSaveRomote";
                var content = KE.html();//得到html代码
                var matchArray1, matchArray2 = [], matchArray3 = [], tmp_matchArray1 = [];
                errorCounter = 0;
                var hostname = location.hostname;
                var reg = /<img[^>]+src=['"](http:\/\/[^'"]*)['"]/ig;
                var subreg = /src=['"]([^'"]*)['"]/ig;
                matchArray1 = content.match(reg);
                //没有远程图片直接提交表单
                if (!matchArray1) {
                    $("#" + CheckboxId)[0].checked = false;
                    showInfoWindow("<p>没有远程图片,请手动提交...</p>");
                    return;
                }
                //只保留非本域名的图片地址
                for (j = 0; j < matchArray1.length; j++) {
                    if (matchArray1[j].indexOf("http://" + hostname) == -1) {
                        tmp_matchArray1.push(matchArray1[j]);
                    }
                }
                matchArray1 = tmp_matchArray1;
                for (j = 0; j < matchArray1.length; j++) {
                    submatch = matchArray1[j].match(subreg);
                    if (submatch && submatch.length > 0) {
                        var url = submatch[0].replace(/('|"|src=)/g, '');
                        matchArray2.push(url);
                        matchArray3.push(url);
                        //console.log(url);
                    }
                }
                //没有子匹配直接提交表单
                if (!matchArray2 || !matchArray2.length) {
                    $("#" + CheckboxId)[0].checked = false;
                    showInfoWindow("<p>没有远程图片,请手动提交...</p>");
                    return;
                }

                //队列开始
                var newQueue = $.AM.createQueue('queue');
                showInfoWindow("开始获取远程图片...");
                for (h = matchArray2.length - 1; h >= 0; h--) {
                    newQueue.offer({
                        url: scriptUrl
                        , type: "POST"
                        , data: {imgurl: matchArray2[h]}
                        , complete: function(x) {
                            var result = x.responseText;
                            try {
                                result = eval("(" + result + ")");
                            } catch (e) {
                                result = {};
                            }
                            var rurl = matchArray2.pop();//原始url
                            var qpr = matchArray3.length - matchArray2.length;
                            //内容替换处理
                            if (!result.error) {
                                var surl = result.url;//保存后的url
                                var content = KE.html();
                                content = content.replace('"' + rurl + '"', '"' + surl + '"');
                                content = content.replace("'" + rurl + "'", '"' + surl + '"');
                                KE.html(content);
                            } else {
                                showInfoWindow(result.message);
                                errorCounter++;
                                if (result.error == 2) {
                                    $.AM.destroyQueue('queue');
                                    return;
                                }
                            }
                            //进度提示
                            if (!matchArray2.length) {
                                $("#" + CheckboxId)[0].checked = false;
                                showInfoWindow("远程图片保存进度[" + qpr + "/" + matchArray3.length + "],失败[" + errorCounter + "]个,<b>保存完毕!<p> 请手动提交...</p>");
                            } else {
                                showInfoWindow("远程图片保存进度[" + qpr + "/" + matchArray3.length + "],失败[" + errorCounter + "]个.");
                            }
                        }
                    });
                }
            }
            var dialog;
            function showInfoWindow(msg) {
                if (!found) {
                    alert(msg);
                    return;
                }
                try {
                    dialog.remove();
                } catch (e) {
                }
                dialog = KindEditor.dialog({
                    width: 400,
                    height: 200,
                    title: '提示信息',
                    body: '<div style="margin:10px;text-align:center;">' + msg + '</div>',
                    closeBtn: {
                        name: '关闭',
                        click: function(e) {
                            dialog.remove();
                        }
                    }
                });
            }
            //###########自动保存相关函数结束#######################
        </script>
    </head>
    <body><form method="post" action="?<?php  echo $this->controller_path ;?>.update" id="cform">
            <div class="content center-block" style="width:95%">
                <hr class="hr1"/>
                <table class="table table-striped table-hover">
                                                                        <tr><td class="text text-primary add-title" >&nbsp;</td><td><input type="hidden" name="aid" value="<?php  echo htmlspecialchars($row['aid'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >标题</td><td><input type="text" name="title" value="<?php  echo htmlspecialchars($row['title'])?>"/></td></tr>
                                                                                                <tr><td class="text text-primary add-title" >内容</td><td><textarea style="width:700px;height:350px;" class="textareahtml" type="text" id="content" name="content"><?php  echo htmlspecialchars($row['content'])?></textarea></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >创建时间</td><td><input type="text" name="create_time" value="<?php  echo htmlspecialchars($row['create_time'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >修改时间</td><td><input type="text" name="modify_time" value="<?php  echo htmlspecialchars($row['modify_time'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >浏览量</td><td><input type="text" name="views" value="<?php  echo htmlspecialchars($row['views'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >类别ID</td><td><input type="text" name="catalog_id" value="<?php  echo htmlspecialchars($row['catalog_id'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >SEO标题</td><td><input type="text" name="seo_title" value="<?php  echo htmlspecialchars($row['seo_title'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >SEO关键字</td><td><input type="text" name="seo_keyword" value="<?php  echo htmlspecialchars($row['seo_keyword'])?>"/></td></tr>
                                                                                        <tr><td class="text text-primary add-title" >SEO描述</td><td><input type="text" name="seo_desc" value="<?php  echo htmlspecialchars($row['seo_desc'])?>"/></td></tr>
                                                                                        <script>found = true;</script>
                        <tr><td>&nbsp;</td><td><label class="text-info"><input type="checkbox" id="cboxSaveRomote"/>保存远程图片</label></td></tr>
                                        <tr><td>&nbsp;</td><td>
                            <span style="padding:1px 20%;"></span> 
                            <a class="btn btn-success" type="text" onclick="$('#cform').submit();
                                    return false;">
                                <span class="glyphicon glyphicon-floppy-save"></span>
                                &nbsp;保存修改&nbsp;
                            </a>
                        </td></tr>
                </table>
            </div>
        </form>
    </body>
</html>