$(function(){
    $('#searchlable').click(function(){
        $(this).toggleClass('glyphicon-minus');
        $(this).toggleClass('glyphicon-plus');
        $(this).siblings('table').toggle();
    });
    $('.cms-page .page_btn_go').addClass('btn').addClass('btn-sm').addClass('btn-primary').css({'text-decoration': 'none', 'margin-top': '-3px'});
    $('.cms-page .page_input_num input').css({'padding': '3px 8px', 'margin-top': '-1px'});
});